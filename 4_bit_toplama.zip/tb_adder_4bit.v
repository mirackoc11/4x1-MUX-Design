`timescale 1ns / 1ps

module tb_adder_4bit;

    reg [3:0] A;
    reg [3:0] B;
    reg Cin;

    wire [3:0] Sum;
    wire Cout;

    adder_4bit uut (
        .A(A),
        .B(B),
        .Cin(Cin),
        .Sum(Sum),
        .Cout(Cout)
    );

    initial begin
        $display("Zaman\t A\t B\t Cin\t |\t Cout\t Sum");
        $display("----------------------------------------------------------");
        $monitor("%4t\t %b\t %b\t %b\t |\t %b\t %b", $time, A, B, Cin, Cout, Sum);

        A = 4'b0000; B = 4'b0000; Cin = 0; #10;
        
        A = 4'b0011; B = 4'b0101; Cin = 0; #10;
        
        A = 4'b1111; B = 4'b0001; Cin = 0; #10;
        
        A = 4'b1010; B = 4'b0110; Cin = 1; #10;
        
        A = 4'b1111; B = 4'b1111; Cin = 1; #10;

        $finish;
    end

endmodule
